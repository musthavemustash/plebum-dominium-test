#!/usr/bin/env python3
"""Check package bytes only; does not authenticate or run the tools."""
from pathlib import Path
import hashlib
import sys
root = Path(__file__).resolve().parent
failures = []
rows = (root / 'SHA256SUMS.txt').read_text().splitlines()
for row in rows:
    expected, name = row.split('  ', 1)
    target = (root / name).resolve()
    if root not in target.parents or not target.is_file():
        failures.append(name)
    elif hashlib.sha256(target.read_bytes()).hexdigest() != expected:
        failures.append(name)
if failures:
    print('FAIL: ' + ', '.join(failures))
    sys.exit(1)
print(f'PASS: {len(rows)} files match package checksums. Public tests only; not custody approval.')
