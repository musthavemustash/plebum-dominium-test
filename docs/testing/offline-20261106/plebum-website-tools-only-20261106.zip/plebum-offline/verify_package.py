from pathlib import Path
import hashlib, sys
root = Path(__file__).resolve().parent
rows = (root / 'SHA256SUMS.txt').read_text().splitlines()
bad = []
for row in rows:
    expected, name = row.split('  ', 1)
    p = (root / name).resolve()
    if not p.is_relative_to(root) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != expected:
        bad.append(name)
print('FAIL: ' + ', '.join(bad) if bad else f'PASS: {len(rows)} files match. Public testing only.')
sys.exit(bool(bad))
