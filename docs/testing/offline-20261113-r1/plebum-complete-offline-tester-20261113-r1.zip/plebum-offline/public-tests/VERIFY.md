# Public alpha checksums — alpha-20261113-r1

Use SHA256SUMS.txt in this folder, or run `python3 verify_package.py`.
Checksums establish byte equality only; public test inputs only.
