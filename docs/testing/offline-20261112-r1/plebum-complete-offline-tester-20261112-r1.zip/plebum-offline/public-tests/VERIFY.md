# Public alpha checksums — alpha-20261108-t5-r4

Use SHA256SUMS.txt in this folder, or run `python3 verify_package.py`.
Checksums establish byte equality only; public test inputs only.
